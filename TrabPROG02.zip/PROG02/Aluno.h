/* TAD: Aluno (matricula, nome, curso) */
typedef struct aluno Aluno;

/* Aloca e retorna um aluno com os dados passados por parâmetro */
Aluno *novo(int matricula, char *nome, char *curso);

/* Libera a memória de um aluno previamente criado */
void libera(Aluno *aluno);

/* Copia os valores de um aluno para as referências informadas */
void acessa(Aluno *aluno, int *matricula, char *nome, char *curso);

/* Atribui novos valores aos campos de um aluno */
void atribui(Aluno *aluno, int matricula, char *nome, char *curso);

/* Atribui o próximo aluno de um aluno */
void atribuiprox(Aluno *aluno, Aluno *proximo);

/* Recupera o próximo aluno de um aluno */
Aluno *acessaprox(Aluno *aluno);

/* Retorna o tamanho em bytes do TAD aluno */
int size();
