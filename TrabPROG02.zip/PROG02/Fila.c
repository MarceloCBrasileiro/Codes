#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Fila.h"
#include "Aluno.h"

struct fila {
	int tamanho,quantidade;
	Aluno* inicio;
    Aluno* fim;
	 
};


Fila *nova(int tamanho) {
	Fila *fila = NULL;

	if(tamanho >0) {
		fila = (Fila *) malloc(sizeof(Fila));
		if(fila != NULL) {
			fila->tamanho = tamanho;
			fila->quantidade = 0;
			fila->inicio= NULL;
            fila->fim = NULL;
			}
		}
	
  
	return fila;
}

void destroi(Fila *fila) {
	if (fila != NULL) {
		Aluno *q = fila->inicio;
    while (q!=NULL){
    	Aluno *t = acessaprox(q);
        free(q);
        q = t;
       
      
    }
  	}
	free(fila);
}


/*funcao extra */
Aluno* retirainicio(Aluno* inicio){
	Aluno *p = acessaprox(inicio);
	free(inicio);
	return p;


}

int adiciona(Fila *fila, Aluno *aluno) {
	if(fila != NULL && (fila->tamanho) > (fila->quantidade) && aluno != NULL) {
		if(fila->quantidade > 0) {
			atribuiprox(fila->fim, aluno);
			fila->fim = aluno;
			(fila->quantidade)++;
			return 1;
		} else {
			fila->inicio = aluno;
			fila->fim = aluno;
			(fila->quantidade)++;
			return 1;
		}
	}
	return 0;
}


int retira(Fila *fila) {
	if (fila != NULL && fila->quantidade > 0) {
		if(fila->inicio=NULL){
			return 0;
		}
		fila->inicio= retirainicio(fila->inicio);
		/*recebe proximo*/
		if(fila->inicio= NULL){
			fila->fim= NULL;
		}
		(fila->quantidade)--;

		return 1;
	}
	
}


Aluno *busca(Fila *fila, int matricula) {
	Aluno* aluno = NULL;
	if(fila != NULL && matricula > 0 && fila->quantidade > 0) {
		int teste, c;
		char nome[51];
		char curso[31];
		Aluno* aluno = fila->inicio;
		acessa(aluno, &teste, nome, curso); 
		while(teste != matricula && c < fila->quantidade) {
			aluno = acessaprox(aluno);
			acessa(aluno, &teste, nome, curso);
			c++;
		}
		if(teste == matricula) { return aluno;
		} else { return NULL; }
	}
	return NULL;	
}

int cheia(Fila *fila) {
	return fila->quantidade == fila->tamanho;
}
