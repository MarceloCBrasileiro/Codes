#include "Aluno.h"

/* TAD: Fila (tamanho)*/
typedef struct fila Fila;
/* Aloca e retorna uma fila de tamanho informado */
Fila* nova(int tamanho);
/* Libera a memória de uma fila previamente criada */
void destroi(Fila *fila);
/* Adiciona um aluno na fila. Retorna 1 se der certo e 0 caso contrário */
int adiciona(Fila *fila, Aluno *aluno);
/* Remove um aluno na fila. Retorna 1 se der certo e 0 caso contrário */
int retira(Fila *fila);
/* Busca por aluno pelo número de matricula. Retorna o aluno se der certo e NULL caso contrário */
Aluno *busca(Fila *fila, int matricula);
/* Retorna 1 se a fila estiver cheia e 0 caso contrário */
int cheia(Fila *fila);

Aluno* inserefim(Aluno* fim, Aluno* aluno);
Aluno* retirainicio(Aluno* inicio);
