package com.example.e.videoimport;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;


public class MainActivity extends AppCompatActivity {
    Uri deleteURI;
    String deleteURIS;
    TextView textTargetUri;
    VideoView targetVideo;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textTargetUri = (TextView)findViewById(R.id.targeturi);
        targetVideo = (VideoView)findViewById(R.id.video);
        deleteURIS = "";
        getRealPathFromURIAleatory();


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            Uri Videouri = data.getData();
            deleteURI= Videouri;
            textTargetUri.setText(Videouri.toString());
            Bitmap bitmap;
            try {
                bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(Videouri));
                targetVideo.setVideoURI(Videouri);

            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }


    }

    void Playandpause(View view){
        if(targetVideo.isPlaying()){
            targetVideo.pause();
        }else{targetVideo.start();}

    }
    void deletepass(View view)  {
        if(deleteURIS.length()<1){

        }else{
            File file = new File(deleteURIS);
            file.delete();
            Intent scanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            scanIntent.setData(Uri.fromFile(file));
            sendBroadcast(scanIntent);
            getRealPathFromURIAleatory();

        }


    }
    public void getRealPathFromURIAleatory() {
        String res = null;
        String[] projection = new String[]{
                MediaStore.Video.Media.DATA,
        };

        Uri videos = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        Cursor cur = getContentResolver().query(videos,
                projection,
                "",
                null,
                ""
        );

        final ArrayList<String> videosPath = new ArrayList<String>();
        String[] proj = { MediaStore.Video.Media.DATA };
        if (cur.moveToFirst()) {

            int dataColumn = cur.getColumnIndex(
                    MediaStore.Images.Media.DATA);
            do {
                videosPath.add(cur.getString(dataColumn));
            } while (cur.moveToNext());
        }
        cur.close();
        final Random random = new Random();
        final int count = videosPath.size();
        if(count<1){

        }else{
            int number = random.nextInt(count);

            res = videosPath.remove(number);
            deleteURIS= res;
            textTargetUri.setText(res);
            targetVideo.setVideoPath(res);

        }




    }


}
